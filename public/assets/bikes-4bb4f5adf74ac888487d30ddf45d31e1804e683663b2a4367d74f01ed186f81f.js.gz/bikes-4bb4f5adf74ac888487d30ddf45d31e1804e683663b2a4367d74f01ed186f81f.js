(function() {
  $(function() {
    return $('.datetimepicker').datetimepicker({
      format: 'MMMM Do YYYY, h:mm'
    });
  });

}).call(this);
